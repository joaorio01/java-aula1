// inclui o módulo http
 var http = require('http');
// inclui o módulo express
 var express = require('express' ) ;

// cria a variável app, pela qual acessaremos
// os métodos / funções existentes no framework
// express
 var app = express () ;
// método use() utilizado para definir em qual
// pasta estará o conteúdo estático
 app. use (express.static('./public' ));

// cria o servidor
 var server = http.createServer(app);

// define o número da porta que o servidor  uvirá
 server.listen(80);


console.log("Servidor rodando .. .")


app.get('/', function (requisicao, resposta){
resposta.redirect('cadastrar-post.html')
})

app.get('/inicio', function (requisicao, resposta){
var titulo = requisicao.query.info;
console.log(titulo);
})

app.get('/inicio', function (requisicao, resposta){
var resumo = requisicao.query.info;
console.log(resumo);
})

app.get('/inicio', function (requisicao, resposta){
var conteudo = requisicao.query.info;
console.log(conteudo);
})


